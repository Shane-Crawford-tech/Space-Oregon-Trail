import Button as Buttonmodule

my_buttons = {}
for i in range(1, 11):
    name = 'Button_{}'.format(i)
    my_buttons[name] = my_buttons.get(name, Buttonmodule.Button(name=name))