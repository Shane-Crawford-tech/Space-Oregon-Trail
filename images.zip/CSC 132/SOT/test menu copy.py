# Python program to create a basic settings menu using the pygame_menu module 

import pygame 
import pygame_menu as pm 
import sys

pygame.init() 

# Screen 
SCREEN_WIDTH, SCREEN_HEIGHT = 700, 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT)) 

# Standard RGB colors 
RED = (255, 0, 0) 
GREEN = (0, 255, 0) 
BLUE = (0, 0, 255) 
CYAN = (0, 100, 100) 
BLACK = (0, 0, 0) 
WHITE = (255, 255, 255) 

BG = pygame.image.load("space.jpg")
BG = pygame.transform.scale(BG, (SCREEN_WIDTH, SCREEN_HEIGHT))
# Main function of the program 

def get_font(font_size, font_name=None):
    
    return pygame.font.Font(font_name, font_size)

def main(): 
	global SCREEN_WIDTH, SCREEN_HEIGHT
	event = pygame.event.poll()

	# List that is displayed while selecting the window resolution level 
	resolution = [("1920x1080", "1920x1080"), 
				("1920x1200", "1920x1200"), 
				("1280x720", "1280x720"), 
				("2560x1440", "2560x1440"), 
				("3840x2160", "3840x2160")] 

	# Creating the settings menu 
	settings = pm.Menu(title="Settings", 
					width=SCREEN_WIDTH, 
					height=SCREEN_HEIGHT, 
					theme=pm.themes.THEME_GREEN) 


	resolution_dropdown = settings.add.dropselect(title="Window Resolution", items=resolution, 
									dropselect_id="Resolution", 
									selection_box_height=6,default=0) 
	screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.RESIZABLE)
	prev_resolution = resolution[0][1]  # Use default resolution as initial previous resolution

	running = True
	while running:
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				sys.exit()



		settings.update(pygame.event.get())
	
		screen.fill((255, 255, 255))
		screen.blit(BG, (0, 0))
		MENU_TEXT = get_font(int(SCREEN_WIDTH * 0.039), None).render("This is the options screen", True, "white")  # Corrected to lowercase
		screen.blit(MENU_TEXT, (int(SCREEN_WIDTH * 0.5) - MENU_TEXT.get_width() // 2, int(SCREEN_HEIGHT * 0.25) - MENU_TEXT.get_height() // 2))
		settings.draw(screen)
		settings.update([event])
		pygame.display.flip()

	# Creating the main menu 
	mainMenu = pm.Menu(title="Main Menu", 
					width=SCREEN_WIDTH, 
					height=SCREEN_HEIGHT, 
					theme=pm.themes.THEME_GREEN) 

	# Adjusting the default values 
	mainMenu._theme.widget_alignment = pm.locals.ALIGN_CENTER 

	# Button that takes to the settings menu when clicked 
	mainMenu.add.button(title="Settings", action=settings, 
						font_color=WHITE, background_color=GREEN) 

	# An empty label that is used to add a seperation between the two buttons 
	mainMenu.add.label(title="") 

	# Exit button that is used to terminate the program 
	mainMenu.add.button(title="Exit", action=pm.events.EXIT, 
						font_color=WHITE, background_color=RED) 

	# Lets us loop the main menu on the screen 
	mainMenu.mainloop(screen) 


if __name__ == "__main__": 
	main() 
