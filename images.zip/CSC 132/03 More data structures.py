# Sets
# don't preserve order
# no duplicates allowed
a = {1, 2, 3, 4, 5}
b = {3, 4, 5, 6, 7}

# Set operations
# Union 
print(a | b)

# Intersecton
print(a & b)

# Difference
print(a-b)
print(b-a)

# Dictionaries
# elements are all KEY-VALUE pairs
offices = {"Jones": 247, "Smith" : 121, "Kennedy" : 108}
print(offices["Jones"])

# Keys are IMMUTABLE (can't be changed), but Values CAN be changed
offices["Kennedy"] = 112
print(offices["Kennedy"])

# KVPairs can be deleted
del offices["Smith"]
print(offices)

# Dictionaries do NOT preserve order

# Waysto iterate through a dictionary
for key in offices.keys():
    print(offices[key])
for key, value in offices.items():
    print(key, ":", value)


# Dictionary Comprehension
# Build a dictionary of cubes
cubes = {x : X**3 for x in range (1, 6)}
print(cubes)