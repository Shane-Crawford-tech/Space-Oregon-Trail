#####################################################################
# author:        Shane Crawford
# date:         4/17/24
# description:  
#####################################################################

# import the abc library to make abstract classes
from abc import ABC, abstractmethod

######################################################################
# An employee class. Its constructor takes the first name, last name and
# pay. It also has email and position as instance variables. It contains
# a single abstract method i.e. applyRaise, and a createEmail function
# that creates an appropriate email address from the employee's first
# and last names.
######################################################################
from abc import ABC, abstractmethod

class Employee(ABC):
    def __init__(self, firstname: str, lastname: str, pay: int, email: str = None, position=None):
        """Initialize an Employee object with firstname, lastname, pay, email, and position."""
        self.firstname = firstname  # Set firstname
        self.lastname = lastname  # Set lastname
        self.pay = pay  # Set pay
        self.position = position  # Set position
        self.email = self.createEmail()  # Call createEmail method to set email

    @property
    def firstname(self):
        """Getter method for firstname."""
        return self._firstname.strip()

    @firstname.setter
    def firstname(self, newFirst):
        """Setter method for firstname. Capitalizes and strips leading/trailing whitespaces."""
        self._firstname = newFirst.strip().capitalize()

    @property
    def lastname(self):
        """Getter method for lastname."""
        return self._lastname.strip()

    @lastname.setter
    def lastname(self, newLast):
        """Setter method for lastname. Capitalizes and strips leading/trailing whitespaces."""
        self._lastname = newLast.strip().capitalize()

    @property
    def pay(self):
        """Getter method for pay."""
        return self._pay

    @pay.setter
    def pay(self, newPay):
        """Setter method for pay. Ensures pay is at least 20000."""
        if newPay >= 20000:
            self._pay = newPay
        else:
            self._pay = 20000

    @property
    def email(self):
        """Getter method for email."""
        return self._email
    
    @email.setter
    def email(self, newEmail):
        """Setter method for email. Validates email format."""
        if "@latech.edu" not in newEmail:
            print("The email is not valid")
        else:
            self._email = newEmail

    def createEmail(self):
        """Create and return an email address based on firstname and lastname."""
        first = self.firstname.lower()
        last = self.lastname.lower()
        email = f"{first}.{last}@latech.edu"
        return email
    
    def __str__(self):
        """String representation of an Employee object."""
        return f"{self.lastname}, {self.firstname} ({self.email})"

    @abstractmethod
    def applyRaise(self, rate):
        """Abstract method to apply a raise to an Employee's pay."""
        raise NotImplementedError
    
class Faculty(Employee):
    def __init__(self, firstname, lastname, position):
        """Initialize a Faculty object with default pay and email."""
        super().__init__(firstname, lastname, 50000, f"{firstname.lower()}.{lastname.lower()}@latech.edu", position)
        self.pay = 50000  # Set pay to default for faculty

    def applyRaise(self, rate):
        """Apply a raise to a Faculty member's pay."""
        if rate > 0:
            self.pay *= rate

    def __str__(self):
        """String representation of a Faculty object."""
        string = super().__str__()
        string += f" -- {self.position}"
        return string

class Staff(Employee):
    def __init__(self, firstname, lastname):
        """Initialize a Staff object with default pay and email."""
        super().__init__(firstname, lastname, 40000, f"{firstname.lower()}.{lastname.lower()}@latech.edu")
        self.pay = 40000  # Set pay to default for staff

    def applyRaise(self, rate):
        """Apply a raise to a Staff member's pay."""
        if rate > 0:
            self.pay += rate






######################################################################
# A faculty class is a subclass of the Employee class above. Its
# constructor receives both names as well as the position. The Faculty
# class also overrides the applyRaise function by multiplying the pay by
# the rate provided as an argument. It also slightly tweaks the __str__
# function in the super class.
######################################################################


######################################################################
# A Staff class is a subclass of the Employee class above. Its
# constructor only receives both names. It also overrides the applyraise
# function but adding the increase (provided as the argument) to the
# pay. It doesn't change anything else from the Employee class.
######################################################################


