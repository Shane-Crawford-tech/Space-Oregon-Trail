#####################################################################
# author:   Shane Crawford
# date:    4/7/24
# description: 
#####################################################################
import pygame
from random import randint, choice
from Item import *
from Constants import *


class Person(Item, pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.colorChoice = 0
        self.size_changed = False
        self.surf = pygame.Surface((self.size, self.size))
        self.surf.fill((0, 0, 0))
        self.rect = self.surf.get_rect(center=(WIDTH // 2, HEIGHT // 2))
        self.color = COLORS
    
    # Method to randomly set the size of the person
    def setSize(self):
        old_center = self.rect.center
        old_size = self.size
        self.size = randint(10, 100)
        self.surf = pygame.Surface((self.size, self.size))
        self.surf.fill(self.color[self.colorChoice])
        dx = (self.size - old_size) // 2
        dy = (self.size - old_size) // 2
        self.rect = self.surf.get_rect(center=(old_center[0] + dx, old_center[1] + dy))

    # Method to randomly set the color of the person
    def setColor(self):
        self.colorChoice = randint(0, 4)
        self.surf.fill(self.color[self.colorChoice])

    # Method to update the state of the person based on user input
    def update(self, pressed_keys):
        if pressed_keys[K_UP]:
            self.goUp()
        if pressed_keys[K_DOWN]:
            self.goDown()
        if pressed_keys[K_LEFT]:
            self.goLeft()
        if pressed_keys[K_RIGHT]:
            self.goRight()
        if pressed_keys[K_SPACE] and not self.size_changed:
            self.setSize()
            self.setColor()
            self.size_changed = True  # Set the flag to True to indicate size has been changed
        # Reset the flag when space key is released
        elif not pressed_keys[K_SPACE]:
            self.size_changed = False

    # Getter and setter for the color property
    @property
    def color(self):
        return self._color
    
    @color.setter
    def color(self, newColor):
        self._color = newColor
    
    # Method to get the position of the person
    def getPosition(self):
        return (self.x, self.y)
    
    # String representation of the person object
    def __str__(self):
        string = super().__str__()
        string += (f"color = {self.color[self.colorChoice]}")
        return string



########################### main game################################
# DO NOT CHANGE ANYTHING BELOW THIS LINE
#####################################################################

# Initialize pygame library and display
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))

# Create a person object
p = Person()
RUNNING = True  # A variable to determine whether to get out of the
                # infinite game loop

while (RUNNING):
    # Look through all the events that happened in the last frame to see
    # if the user tried to exit.
    for event in pygame.event.get():
        if (event.type == KEYDOWN and event.key == K_ESCAPE):
            RUNNING = False
        elif (event.type == QUIT):
            RUNNING = False
        elif (event.type == KEYDOWN and event.key == K_SPACE):
            print(p)

    # Otherwise, collect the list/dictionary of all the keys that were
    # pressed
    pressedKeys = pygame.key.get_pressed()
    
    # and then send that dictionary to the Person object for them to
    # update themselves accordingly.
    p.update(pressedKeys)

    # fill the screen with a color
    screen.fill(WHITE)
    # then transfer the person to the screen
    screen.blit(p.surf, p.getPosition())
    pygame.display.flip()

