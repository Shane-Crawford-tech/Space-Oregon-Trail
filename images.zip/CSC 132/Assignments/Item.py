#####################################################################
# author:      Shane Crawford
# date:        3/20/24
# description: 
#####################################################################
from math import *
from pygame import *
# global Constants to restrict the maximum x and y values that a person object
# can have.
MAX_X = 1000
MAX_Y = 800

# A class representing a person. A person can be initialized with a
# name, as well as x and y coordinates. However, there are default
# values for all those (i.e. player 1, 0 and 0 respectively). A person
# also has a size which is set to 1 by default. A person can go left, 
# go right, go up and go down. A person also has a string function 
# that prints out their name location, and size. A person also has a 
# function that calculates the euclidean distance from another person 
# object.
# Importing sqrt function from math module
from math import sqrt

# Defining a class Person
class Item():
    # Constructor method to initialize a Person object
    def __init__(self, name=None, x=None, y=None):
        # Default size of the person
        self.size = 1
        # Assigning values to instance variables
        self.name = name
        self.x = x
        self.y = y

    # Getter and setter for name property
    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, newName):
        # Assign the default name if newName is None
        self._name = newName or "player 1"

    # Getter and setter for x property
    @property
    def x(self):
        return self._x

    @x.setter
    def x(self, newX):
        # Restricting x coordinate within certain bounds
        if (newX == None or newX < 0):
            self._x = 0
        elif (newX > MAX_X):  # Assuming MAX_X is defined elsewhere
            self._x = MAX_X
        else:
            self._x = newX

    # Getter and setter for y property
    @property
    def y(self):
        return self._y

    @y.setter
    def y(self, newY):
        # Restricting y coordinate within certain bounds
        if (newY == None or newY < 0):
            self._y = 0
        elif (newY > MAX_Y):  # Assuming MAX_Y is defined elsewhere
            self._y = MAX_Y
        else:
            self._y = newY

    # Getter and setter for size property
    @property
    def size(self):
        return self._size

    @size.setter
    def size(self, newSize):
        # Ensuring size is always at least 1
        if (newSize < 1):
            self._size = 1
        else:
            self._size = newSize

    # Method to move left
    def goLeft(self, dis = None):
        if dis == None:
            self.x -=1
        else:
            self.x -= dis

    # Method to move right
    def goRight(self, dis = None):
        if dis == None:
            self.x +=1
        else:
            self.x += dis

    # Method to move up
    def goUp(self, dis = None):
        if dis == None:
            self.y -=1
        else:
            self.y -= dis

    # Method to move down
    def goDown(self, dis = None):
        if dis == None:
            self.y +=1
        else:
            self.y += dis

    # Method to calculate distance between two Person objects
    def getDistance(self, other: "Item"):
        # Calculating Euclidean distance
        dist = sqrt((self.x - other.x)**2 + (self.y - other.y)**2)
        return dist
    
    # Method to return string representation of Person object
    def __str__(self):
        # Formatting string representation
        formating = "{:<20}{:<15}{:<10}{:<10}"
        return formating.format(f"Person({self.name}):", f"size = {self.size},", f"x {self.x}", f"y = {self.y}")
