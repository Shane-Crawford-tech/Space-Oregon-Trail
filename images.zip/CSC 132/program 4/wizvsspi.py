#####################################################################
# author:   Shane Crawford
# date:    4/29/24
# description: 
#####################################################################
import pygame
import random
from Constants import *  # Importing constants
from pygame.locals import (
    RLEACCEL,
    K_UP,
    K_DOWN,
    K_LEFT,
    K_RIGHT,
    K_ESCAPE,
    KEYDOWN,
    QUIT,
)

class Player(pygame.sprite.Sprite):
    """
    Class representing the player character.
    """
    def __init__(self):
        """
        Initialize the player object.
        """
        super(Player, self).__init__()
        # Load and scale player image
        self.surf = pygame.image.load("wizard.png")
        self.surf = pygame.transform.scale(self.surf, (WIDTH/10, HEIGHT/10))
        self.surf.set_colorkey((255, 255, 255), RLEACCEL)  # Set transparent background
        self.rect = self.surf.get_rect(center=(WIDTH // 2, 7*HEIGHT // 8))  # Position player at the bottom center
        self.last_shot = 0  # Record last time player shot a projectile
        self.lives = 3  # Player lives
        self.score = 0  # Player score
        
    def update(self, pressed_keys):
        """
        Update the player's position and actions.
        """
        if pressed_keys[K_LEFT]:
            self.rect.move_ip(-2, 0)
        if pressed_keys[K_RIGHT]:
            self.rect.move_ip(2, 0)
        
        if pressed_keys[K_SPACE]:
            current_time = pygame.time.get_ticks()
            # Limit shooting rate
            if current_time - self.last_shot > 350:    
                self.fire_projectile()
                self.last_shot = current_time

        # Keep player within the screen boundaries
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > WIDTH:
            self.rect.right = WIDTH
        if self.rect.top <= 0:
            self.rect.top = 0
        if self.rect.bottom >= HEIGHT:
            self.rect.bottom = HEIGHT
    
    def fire_projectile(self):
        """
        Fire a projectile.
        """
        new_projectile = Projectile(self.rect.center)
        all_sprites.add(new_projectile)

    def hit(self):
        """
        Process player being hit by an enemy.
        """
        self.lives -= 1
        if self.lives <= 0:
            self.kill()  # Kill player when lives run out

# Load projectile image
projectile_image = pygame.image.load("fireball.png")

class Projectile(pygame.sprite.Sprite):
    """
    Class representing projectiles fired by the player.
    """
    def __init__(self, player_pos):
        """
        Initialize the projectile object.
        """
        super(Projectile, self).__init__()
        self.image = pygame.transform.scale(projectile_image, (WIDTH//20, HEIGHT//20))
        self.rect = self.image.get_rect(center=player_pos)  # Set starting position at player's center
        self.speed = -7  # Projectile speed

    def update(self):
        """
        Update projectile's position.
        """
        self.rect.move_ip(0, self.speed)  # Move vertically
        # Remove the projectile when it goes off the screen
        if self.rect.bottom < 0:
            self.kill()

class Enemy(pygame.sprite.Sprite):
    """
    Class representing enemies.
    """
    def __init__(self):
        """
        Initialize the enemy object.
        """
        super(Enemy, self).__init__()
        self.surf = pygame.image.load("spider.png")
        self.surf = pygame.transform.scale(self.surf, (WIDTH/8, HEIGHT/8))
        self.surf.set_colorkey((255, 255, 255), RLEACCEL)
        self.rect = self.surf.get_rect(center=(0, random.randint(0, 400)))  # Randomize starting position
        self.speed = 1  # Initial speed
        self.initial_speed = 1  # Initial speed

    def update(self):
        """
        Update enemy's position.
        """
        self.rect.move_ip(self.speed, 0)
        # Remove the enemy when it passes the left edge of the screen
        if self.rect.left > WIDTH:
            self.kill()

    def increase_speed(self, score):
        """
        Increase enemy speed based on player's score.
        """
        if score > 20:
            self.speed = self.initial_speed + 4
        elif score > 15:
            self.speed = self.initial_speed + 3
        elif score > 10:
            self.speed = self.initial_speed + 2
        elif score > 5:
            self.speed = self.initial_speed + 1

# Initialize pygame
pygame.init()

# Create the screen object
screen = pygame.display.set_mode((WIDTH, HEIGHT))

# Create a custom event for adding a new enemy
ADDENEMY = pygame.USEREVENT + 1
pygame.time.set_timer(ADDENEMY, 250)

# Instantiate player
player = Player()

enemies = pygame.sprite.Group()
all_sprites = pygame.sprite.Group()
all_sprites.add(player)

running = True

# Load the background image
background_image = pygame.image.load("woodfloor.png")

# Scale the background image to match the screen size
background_image_scaled = pygame.transform.scale(background_image, (WIDTH, HEIGHT))

# Main loop
while running:
    for event in pygame.event.get():
        if event.type == KEYDOWN:
            if event.key == K_ESCAPE:
                running = False
        elif event.type == QUIT:
            running = False
        elif event.type == ADDENEMY:
            if len(enemies) < 1:
                new_enemy = Enemy()
                enemies.add(new_enemy)
                all_sprites.add(new_enemy)

    pressed_keys = pygame.key.get_pressed()
    player.update(pressed_keys)

    if pygame.sprite.spritecollideany(player, enemies):
        player.hit()
        if not player.alive():
            running = False

    for enemy in enemies:
        enemy.increase_speed(player.score)
        if enemy.rect.right >= WIDTH:
            player.hit()
            if not player.alive():
                running = False
            enemy.kill()

    for projectile in all_sprites:
        if isinstance(projectile, Projectile):
            screen.blit(projectile.image, projectile.rect)
            projectile.update()
            if pygame.sprite.spritecollideany(projectile, enemies):
                hit_enemy = pygame.sprite.spritecollideany(projectile, enemies)
                hit_enemy.kill()
                projectile.kill()
                player.score += 1

    enemies.update()

    # Draw the background
    screen.blit(background_image_scaled, (0, 0))

    # Draw other sprites
    for entity in all_sprites:
        if isinstance(entity, Projectile):
            screen.blit(entity.image, entity.rect)
        else:
            screen.blit(entity.surf, entity.rect)

    # Display remaining lives in the bottom right corner
    font = pygame.font.Font(None, 36)
    lives_text = font.render(f"Lives: {player.lives}", True, (255, 255, 255))
    screen.blit(lives_text, (WIDTH - 150, HEIGHT - 50))

    # Display score in the bottom left corner
    score_text = font.render(f"Score: {player.score}", True, (255, 255, 255))
    screen.blit(score_text, (20, HEIGHT - 50))

    pygame.display.flip()
