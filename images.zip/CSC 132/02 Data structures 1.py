from functools import reduce
from math import pi
#handful of useful list functions
#1) filter
#filter(function, mylist)

"""
normal way to create a list of multiples of 3 and 5
multiples = []
for i in range (3, 31):
    if (i % 3 == 0 or i % 5 == 0):
        multiples.append(i)
print(multiples)"""
def multiples_of_3and_5(x):
    return (x % 3 == 0 or x % 5 == 0)

multiples = list(filter(multiples_of_3and_5, range(3, 31)))
#print(multiples)

#2) map
#map(function, mylist)
"""
squares = list(range(1, 10))
for i in range (len(squares)):
    squares[i] *= squares[i]
print(squares)
"""
def m(x):
    return x * x
squares = list(map(m, range(1, 10)))
#print (squares)

#3) reduce
# from functools import reduce
# reduce(function, mylist)
'''
fact = 1
for i in range(1, 11):
    fact *=  i
print (fact)
'''

def f(x, y):
    return x * y

fact = reduce(f, range(1, 11))
#print(fact)

# list comprehensions
'''
cubes = []
for i in range(10):
    cubes.append (i * i * i)
print(cubes)
'''
cubes = [x ** 3 for x in range(10)]
#print(cubes)

sums = [x + y for x in [1,2,3] for y in[3,1,4] if x < y]
#print(sums)

pi_digits = [round(pi, n) for n in range(2,9)]
print(pi_digits)