# POLYMORPHISM -> multiple mehods/functions with the same name in multiple classes
# Method lookup -> finds the right method to call in a class hierarchy

class Vehicle:
    def __init__(self, name):
        self.tires = None
        self.engine = None
        self.owner = name

    def __str__(self):
        return f"vehicle; owner={self.owner}, tires={self.tires}, engine={self.engine}"
    
class Cycle(Vehicle):
    def __init__(self, name):
        super().__init__(name)
        self.tires = 2

    def balance(self):
        pass

class Car(Vehicle):
    def __init__(self, name):
        super().__init__(name)
        self.tires = 4
        self.engine = True

class Bicycle(Cycle):
    def __init__(self, name):
        super().__init__(name)
        self.engine = False

    def __str__(self):
            return "Bycicle!"
        
c1 = Car("John")
c2 = Cycle("Samantha")
b1 = Bicycle("Jane")

print(c1) # Vehicle; owner=John, tires=4, engine=True
print(c2) # Vehicle; owner=Samantha, tires=2, engine=None
print(b1) # Bicycle!

b1.balance()
c1.balance()
